# Witty-Pi-4

Witty Pi is an add-on board that adds realtime clock and power management to your Raspberry Pi. It can define your Raspberry Pi’s ON/OFF sequence, and significantly reduce the energy usage. Witty Pi 4 is the fourth generation of Witty Pi and it has these hardware resources onboard:

*   Factory calibrated and temperature compensated realtime clock with ±2ppm accuracy.
*   Dedicated temperature sensor with 0.125 °C resolution.
*   On-board DC/DC converter that accepts up to 30V DC.
*   AVR 8-bit microcontroller (MCU) with 8 KB programmable flash.

![](https://user-images.githubusercontent.com/6317566/174240816-01f8ac49-55d1-486a-bfef-b6471371125b.png)

Witty Pi 4 supports all Raspberry Pi models with 40-pin header, including A+, B+, 2B, Zero, Zero W, Zero 2 W, 3B, 3B+ and 4B.

### **References:**

*   [Witty Pi 4 Product Page](https://www.uugear.com/product/witty-pi-4/)
*   [Witty Pi 4 User Manual](https://www.uugear.com/doc/WittyPi4_UserManual.pdf)


### Modify the Firmware:
If you want to change the behavior of Witty Pi 4, you can modify the firmware, compile it and upload to your Witty Pi 4.

To compile the firmware, you need to install [ATtinyCore (V1.5.2)](https://github.com/SpenceKonde/ATTinyCore) in your Arduino IDE.

Here are the configurations on your Arduino IDE:

![](https://github.com/uugear/Witty-Pi-4/raw/main/Firmware/WittyPi4_Arduino_Settings.png)

The local shutdown-state correction clears `turnOffFromTXD` when a reboot has
consumed the TXD shutdown request, and on power cut. It prevents the next button,
alarm or protection-triggered shutdown from being mistaken for another reboot.
The Mini uses the `WittyPi4` sketch with `WITTY_PI_4_MINI` defined (product ID
`0x36`); standard builds remain `0x26`, and `WittyPi4_L3V7` remains `0x37`.
Shutdown timing is unchanged. Firmware revision **9** adds atomic RTC calendar
writes alongside the coherent reads introduced in revision 8.

Compile from this checkout with ATTinyCore **1.5.2**, AVR GCC
**7.3.0-atmel3.6.1-arduino7**, LTO and linker relaxation:

```sh
arduino-cli compile \
  --fqbn 'ATTinyCore:avr:attinyx41:chip=841,clock=8internal,pinmapping=old,LTO=enable,wiremode=slave,neopixelport=porta,millis=disabled,eesave=aenable,bod=2v7,bodact=enabled,bodpd=enabled' \
  --build-property compiler.c.elf.extra_flags=-Wl,--relax \
  --output-dir /tmp/wp4-standard Firmware/WittyPi4
```

For Mini, add `--build-property compiler.cpp.extra_flags=-DWITTY_PI_4_MINI`
and select a different output directory. For L3V7, select
`Firmware/WittyPi4_L3V7` without the Mini define.
Standard and Mini occupy **8,174 / 8,192 bytes** of flash; L3V7 occupies
**8,074 / 8,192 bytes**. All three use 223 / 512 bytes of static RAM.

`python3 -m unittest discover -s Firmware/tests -v` exercises the production
shutdown handlers, RTC read/write rollovers, rejected partial calendar writes,
firmware upgrades with retained EEPROM, oscillator validity, internal I2C
NACK/recovery, malformed host reads, and synchronization failure behavior.
These checks and AVR builds are offline evidence only; no board has been
flashed or physically qualified. The checked-in HEX images are rebuilt from
these sources with the configuration above.

To upload the firmware to Witty Pi, you can follow [this document](https://www.uugear.com/portfolio/compile-flash-firmware-for-witty-pi-4/).

### RTC calendar protocol

Install the matching revision-9-or-newer firmware before using this software.
Reads require revision 8; calendar writes require revision 9. Unsupported
operations are rejected rather than falling back to individual calendar bytes.
The host requires `i2ctransfer` from `i2c-tools` and reads seven bytes in one
combined transaction:

```sh
i2ctransfer -y 1 w1@0x08 58 r7
```

The bytes are seconds (including OS), minutes, hours, day, weekday, month, and
year, in the RTC's register encoding. The MCU reads them in one internal-bus
access; alarm decisions likewise use one seconds-through-day access. This
preserves the PCF85063A's frozen calendar across rollovers, as required by
[datasheet section 7.4](https://www.nxp.com/docs/en/data-sheet/PCF85063A.pdf).
RTC values retain the existing local-time convention.

System-to-RTC synchronization sends register 58 and all seven calendar bytes
in one `w8@0x08` transaction. The MCU forwards the complete calendar in one
internal-bus write, keeping the RTC counters frozen until all fields are set.
Incomplete or overlong calendar commands and individual calendar-field writes
are rejected without touching the RTC. Other RTC register writes are unchanged.
The advertised firmware revision comes from the running image, not an older
revision retained in EEPROM.

The host verifies the complete calendar after writing, allowing elapsed time
and one pending RTC tick. Failed transfers or verification leave `TIME_UNKNOWN`
unchanged and report failure. Atomicity here prevents rollover between fields;
it does not provide rollback after power loss or a mid-transfer electrical fault.

The seconds register's oscillator-stop (OS) flag is checked before converting
time. A flagged RTC cannot set Linux time or trigger firmware startup/shutdown
alarms. Rejected reads leave NTP and `TIME_UNKNOWN` unchanged. The boot-time
bad-time check includes OS as well as the existing zero-year initialization
check; its existing system-to-RTC initialization policy is unchanged.

Internal address or register-pointer NACKs produce an empty receive buffer,
not stale/bus data. The bridge encodes that failure as `0xFF` bytes, which
cannot be valid RTC calendar fields. The host rejects that marker, incomplete
transfers, malformed BCD, and invalid dates before attempting synchronization.
A transport failure skips boot-time synchronization in both directions; it
is not treated as an uninitialized RTC.

RTC-to-system synchronization succeeds only if NTP can be disabled and Linux
accepts the new time. If setting the clock fails, the prior enabled NTP state
is restored; failure to restore it is reported explicitly. `TIME_UNKNOWN` is
updated only after a successful clock change. These checks do not detect
electrical corruption that happens to look like valid calendar data.

